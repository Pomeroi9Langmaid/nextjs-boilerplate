/** @type {import('next').NextConfig} */
const nextConfig = {
  // No experimental flags needed
};

export default nextConfig;